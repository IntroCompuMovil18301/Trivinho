package javeriana.edu.co.interfaz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UsuarioMainActivity extends AppCompatActivity {

    Button consultarAlojamiento;
    Button historialAlojamientos;
    Button reseñas;
    Button verMisAlojamientos;
    Button agregarAlojamiento;
    Button alojamientosArrendados;
    Button notificaciones;
    Button verSolicitudes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario_main);
        consultarAlojamiento=(Button) findViewById(R.id.consultarAlojamiento);
        historialAlojamientos=(Button) findViewById(R.id.historialAlojamientos);
        reseñas=(Button) findViewById(R.id.reseñas);
        verMisAlojamientos=(Button) findViewById(R.id.verMisAlojamientos);
        agregarAlojamiento=(Button) findViewById(R.id.agregarAlojamiento);
        alojamientosArrendados=(Button) findViewById(R.id.alojamientosArrendados);;
        notificaciones=(Button) findViewById(R.id.notificaciones);
        verSolicitudes=(Button) findViewById(R.id.verSolicitudes);

        consultarAlojamiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),ConsultarAlojamientoActivity.class);
                startActivity(activar);
            }
        });

        historialAlojamientos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),HistorialDeAlojamiento.class);
                startActivity(activar);
            }
        });

        reseñas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent activar=new Intent(view.getContext(),UsuarioMainActivity.class);
                startActivity(activar);*/
            }
        });

        verMisAlojamientos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),VerMisAlojamientos.class);
                startActivity(activar);
            }
        });

        agregarAlojamiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),AgregarAlojamiento.class);
                startActivity(activar);
            }
        });

        alojamientosArrendados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),AlojamientosArrendados.class);
                startActivity(activar);
            }
        });

        notificaciones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),Notificaciones.class);
                startActivity(activar);
            }
        });

        verSolicitudes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),VerSolicitudes.class);
                startActivity(activar);
            }
        });

    }
}
