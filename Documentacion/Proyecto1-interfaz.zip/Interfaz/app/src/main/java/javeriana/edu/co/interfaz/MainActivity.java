package javeriana.edu.co.interfaz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView logo;
    private Animation anima;
    private TextView registro;
    private Button inicio;
    private EditText nomusuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logo=(ImageView)findViewById(R.id.logo);
        registro=(EditText)findViewById(R.id.nomusuario);
        inicio=(Button)findViewById(R.id.bsesion);
        registro=(TextView)findViewById(R.id.registrarse);
        anima= AnimationUtils.loadAnimation(this,R.anim.iniciologo);
        logo.startAnimation(anima);

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),RegistroActivity.class);
                startActivity(activar);
            }
        });

        inicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),UsuarioMainActivity.class);
                startActivity(activar);
            }
        });
    }
}
