package javeriana.edu.co.interfaz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ConsultarAlojamientoActivity extends AppCompatActivity {
    Button seleccionarAlojamiento;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta);

        seleccionarAlojamiento=(Button) findViewById(R.id.seleccionarAlojamiento);
        seleccionarAlojamiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent activar=new Intent(view.getContext(),ConsultarAlojamientoDetalle.class);
                startActivity(activar);
            }
        });

    }
}
